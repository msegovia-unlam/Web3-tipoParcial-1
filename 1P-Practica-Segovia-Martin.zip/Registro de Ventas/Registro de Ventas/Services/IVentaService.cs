﻿using Registro_de_Ventas.Models;
using System.Collections.Generic;

namespace Registro_de_Ventas.Services
{
    public interface IVentaService
    {
        void RegistrarVenta(int contVendida, int precioVendido, string cliente);
        List<Venta> obtenerTodos();

    }
}
