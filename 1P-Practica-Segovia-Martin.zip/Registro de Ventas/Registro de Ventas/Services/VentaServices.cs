﻿using Registro_de_Ventas.Models;
using System.Collections.Generic;
using System.Linq;

namespace Registro_de_Ventas.Services
{
    public class VentaServices : IVentaService
    {
        static List<Venta> _listaVentas { get; set; } = new List<Venta>()
        {
            new Venta(){ Id = 1, Cliente = "Prueba", Cantidad = 10, Precio=10, Total=100}
        };

        public void RegistrarVenta(int contVendida, int precioVendido, string cliente)
        {
            float totalVendida = contVendida * precioVendido;
            Venta nuevaVenta = new Venta()
            {

                Id = _listaVentas.Max(o => o.Id) + 1,
                Cliente = cliente,
                Cantidad = contVendida,
                Precio = precioVendido,
                Total = totalVendida

            };
            _listaVentas.Add(nuevaVenta);
        }

        List<Venta> IVentaService.obtenerTodos()
        {
            return _listaVentas;
        }
    }
}
