﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Registro_de_Ventas.Models;
using Registro_de_Ventas.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Registro_de_Ventas.Controllers
{
    public class VentasController : Controller
    {
        IVentaService _ventaService;
        public VentasController(IVentaService servicioVentas)
        {
            _ventaService = servicioVentas;
        }

        // GET: VentasController/RegistrarVenta
        public ActionResult RegistrarVenta()
        {
            return View();
        }

        // POST: VentasController/RegistrarVenta
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegistrarVenta(IFormCollection collection)
        {
            int cantVendida = (int)Convert.ToInt64(collection["Cantidad"]);
            int precioVendido = (int)Convert.ToInt64(collection["Precio"]);
            
            string cliente = collection["Cliente"];

            try
            {
                _ventaService.RegistrarVenta(cantVendida, precioVendido, cliente);
                return RedirectToAction(nameof(Resultados));
            }
            catch
            {
                return View();
            }
        }

        // GET: VentasController/Resultados
        public ActionResult Resultados()
        {
            List<Venta> ventas = _ventaService.obtenerTodos();
            return View(ventas);
        }

    }
}
