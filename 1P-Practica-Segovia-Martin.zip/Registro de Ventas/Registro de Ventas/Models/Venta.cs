﻿using System.ComponentModel.DataAnnotations;

namespace Registro_de_Ventas.Models
{
    public class Venta
    {
        public int Id { get; set; }

        [StringLength(50, ErrorMessage = "El cliente no puede tener mas de 50 caracteres")]
        [Required(ErrorMessage = "Campo requerido")]
        public string Cliente { get; set; }

        [Range(2, 299, ErrorMessage = "La cantidad debe ser mayor a 1 y menor a 300")]
        [Required(ErrorMessage = "Campo obligatorio")]
        public int Cantidad { get; set; }

        [Range(10, 999, ErrorMessage = "El precio unitario debe ser mayor o igual a 10 y menor a 1000")]
        [Required(ErrorMessage = "Campo obligatorio")]
        public int Precio { get; set; }

        public float Total { get; set; }
    }
}
